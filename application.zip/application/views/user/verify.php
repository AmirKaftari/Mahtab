<!doctype html>

<html lang="fa">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <title>پرداخت انلاین</title>
  
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/bootstrap-rtl.css">
  <link rel="stylesheet" href="css/stylePage1.css">

  <script src="js/bootstrap.min.js"></script>
<script src="js/jquery-1.11.3.min.js"></script>
</head>

<body style="background-color:#84C0D7">
<div class="container">
    <div class="row">
        <div class="col-md-8 col-lg-push-2">
            <div class="card card-1 " style="padding: 2em; margin: 3em 0">
                <div class="row">

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
