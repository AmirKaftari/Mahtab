﻿<div class="row" >
<div class="panel panel-primary col-xs-6">
    <div class="panel-heading">
        <h3 class="panel-title">دسترسی سریع...</h3>
    </div>
    <div class="panel-body" align="center">
    	
    </div>
</div>

<div class="panel panel-info col-xs-6">
    <div class="panel-heading">
        <h3 class="panel-title">جستجوی سریع...</h3>
    </div>
    <div class="panel-body" align="center">
        
    </div>
</div>

<div class="panel panel-success col-xs-6">
    <div class="panel-heading">
        <h3 class="panel-title">اتمام کلاس ها...</h3>
    </div>
    <div class="panel-body" align="center">
       

            

       
    </div>
</div>
</div>
