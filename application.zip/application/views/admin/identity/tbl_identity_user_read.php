<div class='main'>
        <h2 style="margin-top:0px">Tbl_identity_user اطلاعات</h2>
        <table class="table">
	    <tr><td>IdUser</td><td><?php echo $IdUser; ?></td></tr>
	    <tr><td>Pic</td><td><?php echo $Pic; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('identityusercontroller') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>