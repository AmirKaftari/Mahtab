<div class='main'>
        <h2 style="margin-top:0px">Tbl_user_vip اطلاعات</h2>
        <table class="table">
	    <tr><td>IdUser</td><td><?php echo $IdUser; ?></td></tr>
	    <tr><td>Start_date</td><td><?php echo $Start_date; ?></td></tr>
	    <tr><td>length</td><td><?php echo $length; ?></td></tr>
	    <tr><td>End_date</td><td><?php echo $End_date; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $Status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('tbl_user_vip') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>